import React, { useState } from 'react';
import { Wand2, Download, AlertCircle, Loader2, Image as ImageIcon } from 'lucide-react';
import { generateStrategyImage } from '../services/geminiService';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('A futuristic candlestick chart showing a massive green candle breakout with neon indicators in a cyberpunk style');
  const [size, setSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt) return;
    
    setIsGenerating(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const imageData = await generateStrategyImage(prompt, size);
      if (imageData) {
        setGeneratedImage(imageData);
      } else {
        setError("No image data returned from the model.");
      }
    } catch (err) {
      setError("Failed to generate image. Please try again.");
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-white flex items-center justify-center gap-3">
            <Wand2 className="w-8 h-8 text-purple-500" />
            Strategy Visualizer
          </h1>
          <p className="text-gray-400">
            Generate high-fidelity visualization concepts using Gemini 3 Pro. Perfect for chart art, thumbnails, or strategy concept visualization.
          </p>
        </div>

        {/* Controls */}
        <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl shadow-xl backdrop-blur-sm">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-xl p-4 text-white focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all resize-none h-32"
                placeholder="Describe the image you want to generate..."
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <div className="w-full sm:w-48">
                  <label className="block text-sm font-medium text-gray-300 mb-2">Resolution</label>
                  <select
                    value={size}
                    onChange={(e) => setSize(e.target.value as any)}
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-purple-500/50"
                  >
                    <option value="1K">1K (Standard)</option>
                    <option value="2K">2K (High Def)</option>
                    <option value="4K">4K (Ultra HD)</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt}
                className="w-full sm:w-auto mt-6 sm:mt-0 px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-purple-900/20"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    Generate Art
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Result Area */}
        <div className="bg-gray-900 border-2 border-dashed border-gray-800 rounded-2xl min-h-[400px] flex items-center justify-center relative overflow-hidden group">
          {error && (
            <div className="text-center p-6 text-rose-400 bg-rose-500/10 rounded-xl border border-rose-500/20 max-w-md">
              <AlertCircle className="w-8 h-8 mx-auto mb-2" />
              <p>{error}</p>
            </div>
          )}

          {!generatedImage && !isGenerating && !error && (
            <div className="text-center text-gray-500">
              <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">Ready to Visualize</p>
              <p className="text-sm">Enter a prompt and settings above to start</p>
            </div>
          )}

          {isGenerating && (
             <div className="text-center space-y-4 z-10">
                <div className="relative w-24 h-24 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-purple-500/20 animate-pulse"></div>
                    <div className="absolute inset-0 rounded-full border-t-4 border-purple-500 animate-spin"></div>
                </div>
                <p className="text-purple-400 animate-pulse">Dreaming up your chart...</p>
             </div>
          )}

          {generatedImage && (
            <div className="relative w-full h-full p-4">
              <img
                src={generatedImage}
                alt="Generated Strategy Art"
                className="w-full h-full object-contain rounded-lg shadow-2xl"
              />
              <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                <a
                  href={generatedImage}
                  download={`vegas-touch-viz-${Date.now()}.png`}
                  className="p-3 bg-gray-900/90 hover:bg-white hover:text-gray-900 text-white rounded-full shadow-lg border border-gray-700 transition-colors block"
                  title="Download Image"
                >
                  <Download className="w-6 h-6" />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;
