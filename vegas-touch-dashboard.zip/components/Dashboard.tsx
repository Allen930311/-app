import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Activity, Clock, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { MOCK_SIGNALS, MOCK_PERFORMANCE_DATA } from '../constants';

const Dashboard: React.FC = () => {
  const winRate = 68.5;
  const totalPnL = 12.4;
  const activeSignals = MOCK_SIGNALS.filter(s => s.status === 'ACTIVE');

  return (
    <div className="p-8 space-y-8 h-full overflow-y-auto">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Market Overview</h1>
        <p className="text-gray-400">Real-time monitoring of Vegas Touch strategies across all pairs.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <Activity className="w-6 h-6 text-emerald-400" />
            </div>
            <span className="text-xs font-medium px-2 py-1 bg-gray-700 rounded text-gray-300">+2.4%</span>
          </div>
          <div className="text-3xl font-bold text-white mb-1">{winRate}%</div>
          <div className="text-sm text-gray-400">Win Rate (Last 30 Days)</div>
        </div>

        <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-400" />
            </div>
            <span className="text-xs font-medium px-2 py-1 bg-gray-700 rounded text-gray-300">Target 2.0</span>
          </div>
          <div className="text-3xl font-bold text-white mb-1">2.45R</div>
          <div className="text-sm text-gray-400">Average Risk:Reward</div>
        </div>

        <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-purple-500/10 rounded-lg">
              <TrendingDown className="w-6 h-6 text-purple-400" />
            </div>
            <span className="text-xs font-medium px-2 py-1 bg-gray-700 rounded text-gray-300">Total</span>
          </div>
          <div className="text-3xl font-bold text-white mb-1">{totalPnL}R</div>
          <div className="text-sm text-gray-400">Net Profit (This Week)</div>
        </div>

         <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-orange-500/10 rounded-lg">
              <Clock className="w-6 h-6 text-orange-400" />
            </div>
            <span className="text-xs font-medium px-2 py-1 bg-gray-700 rounded text-gray-300">Live</span>
          </div>
          <div className="text-3xl font-bold text-white mb-1">{activeSignals.length}</div>
          <div className="text-sm text-gray-400">Active Signals</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Chart */}
        <div className="lg:col-span-2 bg-gray-800/50 border border-gray-700 p-6 rounded-2xl">
          <h2 className="text-xl font-bold text-white mb-6">Performance Analytics</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MOCK_PERFORMANCE_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                <XAxis dataKey="name" stroke="#9CA3AF" tick={{fill: '#9CA3AF'}} axisLine={false} tickLine={false} />
                <YAxis stroke="#9CA3AF" tick={{fill: '#9CA3AF'}} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151', color: '#F3F4F6' }}
                  itemStyle={{ color: '#F3F4F6' }}
                  cursor={{fill: '#374151', opacity: 0.4}}
                />
                <Bar dataKey="pnl" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Signals */}
        <div className="bg-gray-800/50 border border-gray-700 p-6 rounded-2xl overflow-hidden flex flex-col">
          <h2 className="text-xl font-bold text-white mb-6">Recent Signals</h2>
          <div className="flex-1 overflow-y-auto pr-2 space-y-3">
            {MOCK_SIGNALS.map((signal) => (
              <div key={signal.id} className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl hover:border-gray-600 transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{signal.symbol}</span>
                    <span className="text-xs bg-gray-700 text-gray-300 px-1.5 py-0.5 rounded">{signal.timeframe}</span>
                  </div>
                  <span className={`text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 ${
                    signal.side === 'Long' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {signal.side === 'Long' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {signal.side.toUpperCase()}
                  </span>
                </div>
                <div className="flex justify-between text-sm text-gray-400">
                  <span>Entry: <span className="text-gray-200">{signal.entry}</span></span>
                  <span>RR: <span className={signal.rr && signal.rr > 0 ? "text-emerald-400" : "text-gray-400"}>
                    {signal.rr ? signal.rr + 'R' : 'Running'}
                  </span></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
